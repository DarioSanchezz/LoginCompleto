package es.sanchez.logincompleto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class ErrorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error);

        ImageView logo = (ImageView) findViewById(R.id.mimo);
        String url = "https://i.pinimg.com/originals/bf/77/84/bf77847eb090cc67555efb51d562060d.png";

        Glide.with(logo.getContext()).load(url).placeholder(R.drawable.ic_launcher_background).into(logo);
    }
}