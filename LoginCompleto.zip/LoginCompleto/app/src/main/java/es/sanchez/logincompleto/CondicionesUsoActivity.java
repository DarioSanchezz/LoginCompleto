package es.sanchez.logincompleto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class CondicionesUsoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.condiciones_uso);

        ImageView logo = (ImageView) findViewById(R.id.img);
        String url = "https://www.sosfactory.com/wp-content/uploads/2018/04/professa.png";

        Glide.with(logo.getContext()).load(url).placeholder(R.drawable.ic_launcher_background).into(logo);
    }
}