package es.sanchez.logincompleto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        ImageView logo = (ImageView) findViewById(R.id.icono2);
        String url = "https://img.freepik.com/fotos-premium/menschen-brillen-cartoon-logo_643934-2839.jpg?w=360";

        Glide.with(logo.getContext()).load(url).placeholder(R.drawable.ic_launcher_background).into(logo);
    }
}