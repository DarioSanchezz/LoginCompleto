package es.sanchez.logincompleto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.time.Instant;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView logo = (ImageView) findViewById(R.id.icono);
        String url = "https://www.sosfactory.com/wp-content/uploads/2018/04/professa.png";

        Glide.with(logo.getContext()).load(url).placeholder(R.drawable.ic_launcher_background).into(logo);

    }
}